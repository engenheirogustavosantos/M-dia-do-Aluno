package pares;

public class pares {

  public static void main(String[] args) {
int valor = 0;

while(valor < 100){

  if(valor == 1){
 
 
  valor = (valor % 2);
  
}else{

valor = valor + 2;
  System.out.println(valor);
  
}
  }
    }
      }